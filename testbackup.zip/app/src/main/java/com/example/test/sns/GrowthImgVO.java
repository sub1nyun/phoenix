package com.example.test.sns;

public class GrowthImgVO {
    int gro_no;
    String gro_img, filename, filepath;

    public int getGro_no() {
        return gro_no;
    }

    public void setGro_no(int gro_no) {
        this.gro_no = gro_no;
    }

    public String getGro_img() {
        return gro_img;
    }

    public void setGro_img(String gro_img) {
        this.gro_img = gro_img;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getFilepath() {
        return filepath;
    }

    public void setFilepath(String filepath) {
        this.filepath = filepath;
    }
}
