package com.example.test.common;

public class CommonVal {
    final String HTTPIP_YSB = "http://192.168.219.173"; //수빈
    final public String HTTPIP_LSJ= "http://192.168.0.4"; //tmdwn
    final public String HTTPIP_jgh= "http://192.168.0.50"; //tmdwn

}
