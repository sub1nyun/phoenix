package com.example.test.diary;

public class detailDTO {
    private String str;

    public detailDTO(String str) {
        this.str = str;
    }

    public String getStr() {
        return str;
    }

    public void setStr(String str) {
        this.str = str;
    }
}
